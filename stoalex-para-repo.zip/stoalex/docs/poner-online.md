# Stoa Lex · ponerlo online y que el correo salga de stoa.consulting

Tres bloques. Ninguno lleva más de diez minutos. Los valores están calculados: solo hay que pegarlos.

---

## A · Crear el buzón en Hostinger

**hPanel → Correos electrónicos → Cuentas de correo → Crear cuenta**

| Campo | Valor |
|---|---|
| Cuenta | `lex` |
| Dominio | `stoa.consulting` |
| Contraseña | genera una larga y guárdala |

Queda `lex@stoa.consulting`.

### Verifica el dominio antes de enviar nada

En **hPanel → Correos → Configuración → Registros DNS**, comprueba que existen los tres:

- **SPF** — autoriza a Hostinger a enviar en tu nombre.
- **DKIM** — firma criptográfica de cada mensaje.
- **DMARC** — qué hacer con lo que no pase los dos anteriores.

Hostinger los crea solos si el dominio apunta a sus nameservers. Si el DNS lo llevas en otro sitio,
copia los tres registros a mano. **Sin esto los correos caen en spam**, y a un abogado que prueba una
herramienta por primera vez no le escribes dos veces.

### Un límite que conviene conocer

El correo de Hostinger está pensado para escribir a personas, no para envíos automáticos: tiene tope
por hora. Para el alta de los primeros clientes sobra. Cuando pases de unos cientos de registros al
día, mueve el envío a Brevo —que ya tienes conectado— sin cambiar nada más que estos mismos campos.

---

## B · Conectarlo a Supabase

**Project Settings → Authentication → SMTP Settings → Enable Custom SMTP**

| Campo | Valor exacto |
|---|---|
| Sender email | `lex@stoa.consulting` |
| Sender name | `Stoa Lex` |
| Host | `smtp.hostinger.com` |
| Port | `465` |
| Username | `lex@stoa.consulting` — la dirección completa, no solo `lex` |
| Password | la del buzón |
| Minimum interval between emails | `10` |

Si el 465 diera problemas, prueba el **587**. Son los dos únicos puertos que admite Hostinger.

### Las plantillas · *Authentication → Email Templates*

**Confirm signup** · asunto: `Tus 24 horas en Stoa Lex empiezan aquí`

```html
<div style="font-family:Georgia,'Times New Roman',serif;max-width:520px;margin:0 auto;padding:32px 24px;color:#14150F;background:#F2F1EC">
  <p style="font-size:20px;margin:0 0 28px;letter-spacing:-.01em">
    Stoa <span style="color:#856327">&#9670;</span> <em>Lex</em>
  </p>
  <h1 style="font-size:26px;font-weight:400;line-height:1.15;margin:0 0 16px">
    Confirma tu correo y empieza
  </h1>
  <p style="font-size:16px;line-height:1.55;color:#43463C;margin:0 0 26px">
    Pulsa el botón y tus 24 horas de acceso ilimitado arrancan en ese momento.
    Sin tarjeta y sin compromiso.
  </p>
  <p style="margin:0 0 28px">
    <a href="{{ .ConfirmationURL }}"
       style="display:inline-block;background:#856327;color:#FBFAF7;text-decoration:none;
              padding:14px 26px;font-family:Arial,sans-serif;font-weight:bold;font-size:15px">
      Empezar mis 24 horas
    </a>
  </p>
  <p style="font-size:14px;line-height:1.5;color:#646659;margin:0">
    Cuando terminen no te quedas a cero: pasas al plan gratuito con 10 consultas al mes.
  </p>
  <p style="font-size:13px;color:#646659;border-top:1px solid #D8D6CC;padding-top:16px;margin:26px 0 0">
    Stoa Consulting S.L. · Madrid · Si no has sido tú, ignora este mensaje.
  </p>
</div>
```

**Reset password** · asunto: `Cambiar tu contraseña de Stoa Lex`

El mismo marco, cambiando el titular por «Elige una contraseña nueva» y el botón por «Cambiar mi
contraseña». Añade debajo: *«El enlace caduca en 24 horas y solo se puede usar una vez.»*

### Y las URL, que es lo que rompía el enlace

**Authentication → URL Configuration**

- **Site URL**: `https://stoa.consulting/stoalex/app.html`
- **Redirect URLs**:
  ```
  https://stoa.consulting/stoalex/app.html
  https://stoa.consulting/stoalex/
  https://stoa.consulting/stoalex/**
  ```

### Un interruptor más

**Authentication → Policies → Leaked Password Protection**: actívalo. Rechaza contraseñas que ya se
han filtrado en brechas conocidas.

---

## C · Subir las páginas

Como stoa.consulting ya vive en Hostinger, el camino corto es el suyo — y además te da la URL
definitiva en vez de una provisional.

**hPanel → Archivos → Administrador de archivos**

1. Entra en `public_html`.
2. Crea la carpeta `stoalex`.
3. Sube dentro `index.html`, `app.html` y `404.html`.

Listo: `https://stoa.consulting/stoalex/`

Las tres páginas son autocontenidas y usan rutas relativas, así que funcionan en cualquier carpeta
sin tocar una línea.

---

## Comprobación final

1. Regístrate en `https://stoa.consulting/stoalex/` con un correo real.
2. El mensaje debe llegar **desde lex@stoa.consulting**, en castellano y a la bandeja de entrada.
3. Al pulsar el enlace debes caer en el escritorio, ya dentro.
4. Pulsa el atajo *Ejemplo: LAU, art. 9, 8·01·2019*.
5. Debe salir la redacción del RDL 21/2018 —no la vigente hoy— y la ventana de 35 días marcada.

Si falla en el 2, es el DNS del dominio. Si falla en el 3, son las URL del bloque B. Si falla en el
5, dime el mensaje exacto.
