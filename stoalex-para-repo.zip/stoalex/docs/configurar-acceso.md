# Stoa Lex · los tres ajustes que faltan

Tus dos problemas tienen la misma raíz: **Supabase todavía está con su configuración por defecto.**
Son tres cosas, todas en el panel, y ninguna lleva más de diez minutos.

Panel del proyecto: https://supabase.com/dashboard/project/fqsgcydvjnkfhnbrlcdt

---

## 1. El error al confirmar · *Authentication → URL Configuration*

Ahora mismo el Site URL es `http://localhost:3000`, así que el enlace del correo te manda a una
dirección que no existe. Por eso ves el error.

**Site URL**

```
https://stoa.consulting/stoalex/app.html
```

**Redirect URLs** — añade estas cuatro, una por línea:

```
https://stoa.consulting/stoalex/app.html
https://stoa.consulting/stoalex/
https://stoa.consulting/stoalex/**
http://localhost:*/**
```

La última solo para tus pruebas en local; quítala cuando lances.

> Si en tu web la ruta acaba siendo distinta (por ejemplo `/stoalex/app` sin extensión, o
> `/stoa-lex/`), pon esa. Lo que importa es que coincida exactamente con donde subas `app.html`.

Con esto, el enlace del correo aterriza en el escritorio, la sesión se abre sola y las 24 horas
empiezan en ese momento. La página ya está preparada para recibirlo: lee el token, lo canjea, limpia
la URL y muestra el aviso de bienvenida.

---

## 2. El correo llega desde Supabase · *Project Settings → Authentication → SMTP Settings*

El remitente por defecto es `noreply@mail.app.supabase.io`. Además de quedar mal, el SMTP gratuito de
Supabase está limitado a unos pocos correos por hora: **no aguanta un lanzamiento.**

Tienes **Brevo** conectado, que sirve perfectamente. Activa *Enable Custom SMTP* y rellena:

| Campo | Valor |
|---|---|
| Sender email | `hola@stoa.consulting` |
| Sender name | `Stoa Lex` |
| Host | `smtp-relay.brevo.com` |
| Port | `587` |
| Username | el que te da Brevo en *SMTP & API → SMTP* (no es tu correo) |
| Password | la clave SMTP de Brevo |
| Minimum interval | `10` segundos |

Antes de que funcione, en Brevo hay que **verificar el dominio** `stoa.consulting`: te dará unos
registros DNS (SPF, DKIM y DMARC) que hay que añadir donde tengas el dominio. Sin eso, los correos
acaban en spam — y a un abogado que prueba una herramienta por primera vez no le vuelves a escribir.

---

## 3. Los correos están en inglés · *Authentication → Email Templates*

### Confirm signup

Asunto: `Tus 24 horas en Stoa Lex empiezan aquí`

```html
<div style="font-family:Georgia,serif;max-width:520px;margin:0 auto;padding:32px 24px;color:#14150F">
  <p style="font-size:20px;letter-spacing:-.01em;margin:0 0 24px">
    Stoa <span style="color:#856327">&#9670;</span> <em>Lex</em>
  </p>
  <h1 style="font-size:26px;font-weight:400;line-height:1.15;margin:0 0 16px">
    Confirma tu correo y empieza
  </h1>
  <p style="font-size:16px;line-height:1.55;color:#43463C;margin:0 0 24px">
    Pulsa el botón y tus 24 horas de acceso ilimitado arrancan en ese momento.
    Sin tarjeta y sin compromiso.
  </p>
  <p style="margin:0 0 28px">
    <a href="{{ .ConfirmationURL }}"
       style="display:inline-block;background:#856327;color:#FBFAF7;text-decoration:none;
              padding:14px 26px;font-family:Arial,sans-serif;font-weight:bold;font-size:15px">
      Empezar mis 24 horas
    </a>
  </p>
  <p style="font-size:14px;line-height:1.5;color:#646659;margin:0 0 8px">
    Cuando terminen no te quedas a cero: pasas al plan gratuito con 10 consultas al mes.
  </p>
  <p style="font-size:13px;color:#646659;border-top:1px solid #D8D6CC;padding-top:16px;margin:24px 0 0">
    Stoa Consulting S.L. · Madrid · Si no has sido tú, ignora este mensaje.
  </p>
</div>
```

### Reset password

Asunto: `Cambiar tu contraseña de Stoa Lex`

Mismo marco, con `{{ .ConfirmationURL }}` y el texto: *«Pulsa para elegir una contraseña nueva. El
enlace caduca en 24 horas y solo se puede usar una vez.»* El escritorio detecta que vienes de una
recuperación y te pide directamente la contraseña nueva.

---

## Lo que ya funciona sin que toques nada

**La consulta a fecha ya consulta el BOE de verdad.** No es una maqueta.

Desplegué una función en el servidor (`consulta`) que:

1. Comprueba tu identidad y tu cuota antes de trabajar.
2. Llama a la API de legislación consolidada del BOE.
3. Lee **todas** las redacciones del artículo con sus fechas de vigencia.
4. Elige la que regía en la fecha que le has dado.
5. Devuelve el texto, la línea temporal completa y la norma que introdujo cada cambio.
6. Lo guarda en tu historial.

Si la consulta falla, **anula el registro para no gastarte cuota**. Y si la fecha es anterior al
histórico disponible, lo dice en lugar de devolver algo plausible y equivocado.

Pruébalo con el atajo que trae el escritorio: **LAU, artículo 9, 8 de enero de 2019.** Verás que la
redacción aplicable no es la de hoy, y verás la ventana de 35 días del RDL 21/2018 marcada en la
línea temporal. Eso es exactamente lo que ningún competidor te da.

### Qué hay en el escritorio

- **Consulta a fecha** con doce normas precargadas, y campo libre para cualquier otra por su
  identificador del BOE.
- **Historial** de consultas: cada una con su fecha aplicable y su resultado completo, recuperable
  con un clic.
- **Expediente**: subida de contratos y resoluciones a un almacén privado. Cada usuario solo ve su
  carpeta. *El análisis automático del documento aún no está — de momento se archivan.*
- **Estado de cuenta** siempre visible: horas de prueba restantes o consultas del mes.

---

## Cómo subir las páginas

Dos archivos en la misma carpeta:

```
stoa.consulting/stoalex/index.html   ← la landing (stoalex.html renombrado)
stoa.consulting/stoalex/app.html     ← el escritorio
```

Tienen que estar **juntos**: la landing enlaza al escritorio con una ruta relativa, así que funciona
en cualquier carpeta sin tocar nada.

---

## Comprobación de extremo a extremo

1. Haz los tres ajustes de arriba.
2. Entra en `stoa.consulting/stoalex/` desde el móvil y regístrate con un correo real.
3. El correo debe llegar **desde hola@stoa.consulting** y en castellano.
4. Al pulsar el enlace debes caer en el escritorio, ya dentro, con el aviso de bienvenida.
5. Pulsa el atajo *Ejemplo: LAU, art. 9, 8·01·2019*.
6. Comprueba que aparece la redacción del RDL 21/2018 y no la vigente hoy.

Si algo falla en el paso 3 o 4, es la configuración de las URL del punto 1. Si falla en el 5, dímelo
con lo que ponga el mensaje de error.

---

## Añadido el 23 de agosto · plan Despacho y vista de equipo

**La cuenta `antelojosemanuel@gmail.com` ya tiene el plan Despacho activo**, concedido a mano y sin
cobro, con **6 plazas** y un despacho llamado *Despacho Stoa · demostración*. Queda registrado en
`eventos` como `plan_concedido_manual` y en las notas internas del perfil, para que no se confunda
con una suscripción real cuando mires las métricas.

Un apunte: al mirarlo vi que **tu correo sí se confirmó** (a las 07:45). El error que viste fue solo
el redirect, no el alta. La cuenta estaba bien desde el principio.

### Lo que aparece ahora en el escritorio con plan Despacho

- **Contador de plazas** en rombos: llenas, pendientes de aceptar y libres.
- **Lista de letrados** con su rol y cuántas consultas lleva cada uno.
- **Invitar por correo**, solo para el titular. Cuando esa persona se registre con ese correo, entra
  automáticamente en el despacho y con el plan Despacho activo — sin que tengas que hacer nada.
- **Coste calculado**: 129 € por los dos primeros más 49 € por cada plaza adicional.
- **Pestañas «Mías» y «Del despacho»** en el historial.
- **Botón «Compartir con el despacho»** en cada resultado. Por defecto **nada se comparte**: cada
  letrado ve solo lo suyo hasta que decide compartirlo. En un despacho es la única política
  defendible, porque puede haber asuntos con partes contrarias dentro de la misma firma.

### Un ajuste más de seguridad · *Authentication → Policies*

Activa **Leaked Password Protection**. Comprueba las contraseñas contra la base de HaveIBeenPwned y
rechaza las que ya se han filtrado. Es un interruptor y evita el modo de entrada más común.
