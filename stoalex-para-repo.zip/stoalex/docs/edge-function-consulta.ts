import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const BOE = "https://www.boe.es/datosabiertos/api/legislacion-consolidada/id";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...CORS, "Content-Type": "application/json" } });

/* ---------- utilidades de fecha: el BOE usa AAAAMMDD ---------- */
const aNum = (iso: string) => Number(iso.replaceAll("-", ""));
const aIso = (n: string) => `${n.slice(0, 4)}-${n.slice(4, 6)}-${n.slice(6, 8)}`;
const diaAntes = (n: string) => {
  const d = new Date(Date.UTC(+n.slice(0, 4), +n.slice(4, 6) - 1, +n.slice(6, 8)));
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
};

/* ---------- parseo del XML del BOE ---------- */
const desescapar = (s: string) =>
  s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
   .replace(/&#39;/g, "'").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&");

function parrafos(xml: string): string[] {
  const out: string[] = [];
  const re = /<p\b[^>]*>([\s\S]*?)<\/p>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const t = desescapar(m[1].replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
    if (t) out.push(t);
  }
  return out;
}

interface Version {
  id_norma: string; fecha_publicacion: string; fecha_vigencia: string;
  parrafos: string[];
}

function versiones(xml: string): Version[] {
  const out: Version[] = [];
  const re = /<version\b([^>]*)>([\s\S]*?)<\/version>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const at = m[1];
    const g = (k: string) => (at.match(new RegExp(`${k}="([^"]*)"`)) ?? ["", ""])[1];
    out.push({
      id_norma: g("id_norma"),
      fecha_publicacion: g("fecha_publicacion"),
      fecha_vigencia: g("fecha_vigencia"),
      parrafos: parrafos(m[2]),
    });
  }
  return out.sort((a, b) => Number(a.fecha_vigencia) - Number(b.fecha_vigencia));
}

async function pedirBoe(url: string) {
  const r = await fetch(url, { headers: { Accept: "application/xml" } });
  const t = await r.text();
  return { ok: r.ok && !t.includes("<code>404</code>"), texto: t, status: r.status };
}

/* ================================================================= */
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "metodo_no_permitido" }, 405);

  const auth = req.headers.get("Authorization") ?? "";
  if (!auth.startsWith("Bearer ")) return json({ error: "no_autenticado" }, 401);

  // cliente con el token del usuario: auth.uid() resuelve y RLS se aplica
  const sb = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );

  const { data: { user }, error: eUser } = await sb.auth.getUser();
  if (eUser || !user) return json({ error: "no_autenticado" }, 401);

  let body: { norma_id?: string; articulo?: string; bloque?: string; fecha?: string };
  try { body = await req.json(); } catch { return json({ error: "json_invalido" }, 400); }

  const normaId = (body.norma_id ?? "").trim().toUpperCase();
  const fecha = (body.fecha ?? "").trim();
  const bloque = (body.bloque ?? "").trim() ||
    "a" + (body.articulo ?? "").trim().replace(/[^\dA-Za-z]/g, "");

  if (!/^BOE-A-\d{4}-\d+$/.test(normaId)) return json({ error: "norma_invalida" }, 400);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha))  return json({ error: "fecha_invalida" }, 400);
  if (bloque === "a")                      return json({ error: "articulo_vacio" }, 400);

  /* ---- 1. cuota: se comprueba y se reserva antes de trabajar ---- */
  const { data: reg, error: eReg } = await sb.rpc("registrar_consulta", {
    p_pregunta: `${normaId} · ${bloque} · a ${fecha}`,
    p_fecha_aplicable: fecha,
    p_motivo_fecha: "indicada_por_usuario",
    p_normas: [{ norma: normaId, bloque }],
    p_aviso_trans: false,
  });
  if (eReg) return json({ error: "error_cuota", detalle: eReg.message }, 500);
  if (!reg?.ok) return json({ error: reg?.motivo ?? "cuota_agotada", plan: reg?.plan, cuota: reg?.cuota }, 402);
  const consultaId = reg.consulta_id as string;

  const anular = async () => { await sb.from("consultas").delete().eq("id", consultaId); };

  try {
    /* ---- 2. texto del bloque ---- */
    const rb = await pedirBoe(`${BOE}/${normaId}/texto/bloque/${bloque}`);
    if (!rb.ok) {
      await anular();
      return json({ error: "bloque_no_encontrado", bloque,
                    ayuda: "Comprueba el número de artículo. Para disposiciones usa el identificador del BOE (por ejemplo dt3)." }, 404);
    }

    const vs = versiones(rb.texto);
    if (!vs.length) { await anular(); return json({ error: "sin_versiones" }, 502); }

    const tituloBloque = (rb.texto.match(/<bloque\b[^>]*titulo="([^"]*)"/) ?? ["", bloque])[1];

    /* ---- 3. título oficial de la norma ---- */
    let tituloNorma = normaId;
    try {
      const rm = await pedirBoe(`${BOE}/${normaId}/metadatos`);
      const t = rm.texto.match(/<titulo>([\s\S]*?)<\/titulo>/);
      if (t) tituloNorma = desescapar(t[1].replace(/<[^>]+>/g, "")).trim();
    } catch { /* el título es accesorio */ }

    /* ---- 4. versión aplicable a la fecha ---- */
    const f = aNum(fecha);
    let idx = -1;
    for (let i = 0; i < vs.length; i++) if (Number(vs[i].fecha_vigencia) <= f) idx = i;

    if (idx === -1) {
      await anular();
      return json({
        error: "anterior_al_historico",
        primera_vigencia: aIso(vs[0].fecha_vigencia),
        ayuda: `El histórico de este precepto empieza el ${aIso(vs[0].fecha_vigencia)}.`,
      }, 404);
    }

    const v = vs[idx];
    const sig = vs[idx + 1];
    const esVigenteHoy = idx === vs.length - 1;

    const linea = vs.map((x, i) => ({
      desde: aIso(x.fecha_vigencia),
      hasta: vs[i + 1] ? diaAntes(vs[i + 1].fecha_vigencia) : null,
      norma_modificadora: x.id_norma,
      aplicable: i === idx,
    }));

    const resultado = {
      norma: { id: normaId, titulo: tituloNorma,
               enlace: `https://www.boe.es/buscar/act.php?id=${normaId}` },
      precepto: { bloque, titulo: tituloBloque },
      fecha_consultada: fecha,
      redaccion_aplicable: {
        vigente_desde: aIso(v.fecha_vigencia),
        vigente_hasta: sig ? diaAntes(sig.fecha_vigencia) : null,
        introducida_por: v.id_norma,
        enlace_modificadora: `https://www.boe.es/buscar/doc.php?id=${v.id_norma}`,
        texto: v.parrafos,
      },
      es_la_vigente_hoy: esVigenteHoy,
      total_redacciones: vs.length,
      linea_temporal: linea,
      redaccion_actual: esVigenteHoy ? null : {
        vigente_desde: aIso(vs[vs.length - 1].fecha_vigencia),
        texto: vs[vs.length - 1].parrafos,
      },
      aviso_oficial:
        "Texto consolidado sin valor jurídico oficial. Solo se reflejan modificaciones y derogaciones expresas. " +
        "Basado en datos de la Agencia Estatal Boletín Oficial del Estado (boe.es).",
    };

    /* ---- 5. guardar para el escritorio ---- */
    await sb.from("consultas").update({
      titulo: `${tituloBloque} · ${tituloNorma.slice(0, 80)}`,
      respuesta: resultado,
    }).eq("id", consultaId);

    const { data: estado } = await sb.rpc("estado_cuenta");
    return json({ ok: true, consulta_id: consultaId, resultado, estado });

  } catch (e) {
    await anular();
    return json({ error: "fallo_consulta", detalle: String(e) }, 500);
  }
});
