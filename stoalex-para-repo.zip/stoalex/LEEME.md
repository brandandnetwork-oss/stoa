# Stoa Lex

Subcarpeta del repositorio `stoa`. **No toca nada de la web principal**: todo cuelga de `/stoalex/`.

| Archivo | Qué es |
|---|---|
| `index.html` | Landing: propuesta, precios y alta |
| `app.html` | Escritorio: consulta a fecha, historial, expediente y despacho |
| `404.html` | Redirección a la portada de Stoa Lex |
| `docs/poner-online.md` | Correo propio, URLs de Supabase y publicación |
| `docs/configurar-acceso.md` | Ajustes de acceso y plan Despacho |
| `docs/integracion.md` | Integración de Stripe |
| `docs/edge-function-consulta.ts` | Función de servidor que consulta el BOE |
| `sql/esquema.sql` | Esquema de base de datos |

Ambas páginas son autocontenidas y usan rutas relativas: funcionan en cualquier carpeta sin cambios.

La clave de Supabase incrustada es **publicable por diseño**. No da acceso a datos: todo está
protegido por políticas de fila, y ni el plan ni la ventana de prueba ni los campos de facturación
se pueden tocar desde el navegador. La clave de servicio nunca sale del servidor.

© 2026 Stoa Consulting S.L. · Herramienta de apoyo profesional, no asesoramiento jurídico.
Basado en datos de la Agencia Estatal Boletín Oficial del Estado (boe.es).
