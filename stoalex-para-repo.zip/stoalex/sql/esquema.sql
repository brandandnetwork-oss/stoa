-- =====================================================================
-- STOA LEX · esquema inicial
-- Modelo de acceso: 24 h ilimitadas al registrarse (sin tarjeta),
-- y al expirar el usuario NO cae a cero: pasa a Free con 10 consultas/mes.
-- Planes: free (0) · basico (29) · profesional (69) · despacho (129)
-- =====================================================================

create type public.plan_tipo as enum ('prueba','free','basico','profesional','despacho');
create type public.suscripcion_estado as enum
  ('ninguna','activa','impago','cancelada','periodo_prueba','incompleta');

-- ---------------------------------------------------------------------
-- PERFILES
-- ---------------------------------------------------------------------
create table public.perfiles (
  id                      uuid primary key references auth.users(id) on delete cascade,
  email                   text not null,
  nombre                  text,
  despacho                text,
  colegio                 text,            -- colegio de abogados (opcional)
  n_colegiado             text,            -- opcional: sello de confianza, no requisito
  telefono                text,

  plan                    public.plan_tipo not null default 'prueba',
  trial_inicio            timestamptz not null default now(),
  trial_fin               timestamptz not null default (now() + interval '24 hours'),

  stripe_customer_id      text unique,
  stripe_subscription_id  text unique,
  estado_suscripcion      public.suscripcion_estado not null default 'ninguna',
  periodo_actual_fin      timestamptz,
  cancelar_al_final       boolean not null default false,

  -- seguimiento comercial: "luego contactamos con ellos"
  contactado              boolean not null default false,
  contactado_el           timestamptz,
  notas_internas          text,
  origen                  text,            -- utm / campaña / colegio

  creado_el               timestamptz not null default now(),
  actualizado_el          timestamptz not null default now()
);

comment on column public.perfiles.n_colegiado is
  'Opcional. Ningun competidor verifica colegiacion; aqui es sello de confianza voluntario, nunca requisito de alta.';

create index perfiles_trial_fin_idx    on public.perfiles (trial_fin);
create index perfiles_plan_idx         on public.perfiles (plan);
create index perfiles_contactado_idx   on public.perfiles (contactado) where contactado = false;
create index perfiles_stripe_cust_idx  on public.perfiles (stripe_customer_id);

-- ---------------------------------------------------------------------
-- EQUIPOS (plan Despacho: 2 usuarios incluidos, +49 EUR por usuario extra)
-- ---------------------------------------------------------------------
create table public.equipos (
  id                uuid primary key default gen_random_uuid(),
  nombre            text not null,
  propietario_id    uuid not null references public.perfiles(id) on delete restrict,
  plazas            int  not null default 2 check (plazas >= 2),
  creado_el         timestamptz not null default now()
);

create table public.equipo_miembros (
  equipo_id   uuid not null references public.equipos(id) on delete cascade,
  usuario_id  uuid not null references public.perfiles(id) on delete cascade,
  rol         text not null default 'miembro' check (rol in ('propietario','miembro')),
  alta_el     timestamptz not null default now(),
  primary key (equipo_id, usuario_id)
);

create index equipo_miembros_usuario_idx on public.equipo_miembros (usuario_id);

-- ---------------------------------------------------------------------
-- CONSULTAS (uso real + trazabilidad temporal, que es el producto)
-- ---------------------------------------------------------------------
create table public.consultas (
  id                uuid primary key default gen_random_uuid(),
  usuario_id        uuid not null references public.perfiles(id) on delete cascade,
  creada_el         timestamptz not null default now(),

  pregunta          text,
  fecha_aplicable   date,        -- la fecha que el sistema resolvio para responder
  motivo_fecha      text,        -- 'celebracion' | 'devengo' | 'comision' | 'incoacion' | ...
  normas_citadas    jsonb not null default '[]'::jsonb,
  aviso_transitorio boolean not null default false,

  plan_en_uso       public.plan_tipo not null,
  tokens_entrada    int,
  tokens_salida     int,
  latencia_ms       int
);

create index consultas_usuario_fecha_idx on public.consultas (usuario_id, creada_el desc);
create index consultas_mes_idx on public.consultas (usuario_id, (date_trunc('month', creada_el)));

-- ---------------------------------------------------------------------
-- EVENTOS (embudo: registro -> primera consulta -> fin de trial -> pago)
-- ---------------------------------------------------------------------
create table public.eventos (
  id          bigserial primary key,
  usuario_id  uuid references public.perfiles(id) on delete cascade,
  tipo        text not null,
  metadatos   jsonb not null default '{}'::jsonb,
  creado_el   timestamptz not null default now()
);

create index eventos_tipo_idx on public.eventos (tipo, creado_el desc);
create index eventos_usuario_idx on public.eventos (usuario_id, creado_el desc);
-- =====================================================================
-- STOA LEX · logica de cuotas, alta automatica y RLS
-- =====================================================================

-- ---------------------------------------------------------------------
-- Cuota mensual por plan. NULL = ilimitado.
-- ---------------------------------------------------------------------
create or replace function public.cuota_mensual(p public.plan_tipo)
returns int
language sql immutable
as $$
  select case p
    when 'prueba'       then null   -- ilimitado durante las 24 h
    when 'free'         then 10
    when 'basico'       then 40
    when 'profesional'  then null
    when 'despacho'     then null
  end;
$$;

-- ---------------------------------------------------------------------
-- Plan efectivo: degrada 'prueba' a 'free' cuando expiran las 24 h.
-- No borra al usuario ni lo bloquea: lo conserva.
-- ---------------------------------------------------------------------
create or replace function public.plan_efectivo(p_usuario uuid)
returns public.plan_tipo
language sql stable security definer set search_path = public
as $$
  select case
    when pf.plan = 'prueba' and pf.trial_fin > now() then 'prueba'::public.plan_tipo
    when pf.plan = 'prueba'                          then 'free'::public.plan_tipo
    when pf.plan in ('basico','profesional','despacho')
         and pf.estado_suscripcion not in ('activa','periodo_prueba')
                                                     then 'free'::public.plan_tipo
    else pf.plan
  end
  from public.perfiles pf
  where pf.id = p_usuario;
$$;

-- ---------------------------------------------------------------------
-- Estado de cuenta: lo que pinta la interfaz.
-- ---------------------------------------------------------------------
create or replace function public.estado_cuenta(p_usuario uuid default auth.uid())
returns jsonb
language plpgsql stable security definer set search_path = public
as $$
declare
  v_perfil    public.perfiles;
  v_plan      public.plan_tipo;
  v_cuota     int;
  v_usadas    int;
  v_restantes int;
begin
  select * into v_perfil from public.perfiles where id = p_usuario;
  if not found then
    return jsonb_build_object('error','perfil_no_encontrado');
  end if;

  v_plan  := public.plan_efectivo(p_usuario);
  v_cuota := public.cuota_mensual(v_plan);

  select count(*) into v_usadas
  from public.consultas
  where usuario_id = p_usuario
    and creada_el >= date_trunc('month', now());

  v_restantes := case when v_cuota is null then null else greatest(v_cuota - v_usadas, 0) end;

  return jsonb_build_object(
    'plan',                v_plan,
    'plan_contratado',     v_perfil.plan,
    'en_prueba',           (v_plan = 'prueba'),
    'trial_fin',           v_perfil.trial_fin,
    'horas_restantes',     greatest(round(extract(epoch from (v_perfil.trial_fin - now())) / 3600.0, 1), 0),
    'cuota_mensual',       v_cuota,
    'consultas_usadas',    v_usadas,
    'consultas_restantes', v_restantes,
    'ilimitado',           (v_cuota is null),
    'puede_consultar',     (v_cuota is null or v_usadas < v_cuota),
    'estado_suscripcion',  v_perfil.estado_suscripcion,
    'periodo_actual_fin',  v_perfil.periodo_actual_fin,
    'email',               v_perfil.email,
    'nombre',              v_perfil.nombre
  );
end;
$$;

-- ---------------------------------------------------------------------
-- Registrar consulta con control de cuota atomico.
-- ---------------------------------------------------------------------
create or replace function public.registrar_consulta(
  p_pregunta        text default null,
  p_fecha_aplicable date default null,
  p_motivo_fecha    text default null,
  p_normas          jsonb default '[]'::jsonb,
  p_aviso_trans     boolean default false
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  v_usuario uuid := auth.uid();
  v_plan    public.plan_tipo;
  v_cuota   int;
  v_usadas  int;
  v_id      uuid;
begin
  if v_usuario is null then
    return jsonb_build_object('ok', false, 'motivo', 'no_autenticado');
  end if;

  v_plan  := public.plan_efectivo(v_usuario);
  v_cuota := public.cuota_mensual(v_plan);

  if v_cuota is not null then
    select count(*) into v_usadas
    from public.consultas
    where usuario_id = v_usuario
      and creada_el >= date_trunc('month', now());

    if v_usadas >= v_cuota then
      insert into public.eventos (usuario_id, tipo, metadatos)
      values (v_usuario, 'cuota_agotada', jsonb_build_object('plan', v_plan, 'cuota', v_cuota));
      return jsonb_build_object('ok', false, 'motivo', 'cuota_agotada',
                                'plan', v_plan, 'cuota', v_cuota);
    end if;
  end if;

  insert into public.consultas
    (usuario_id, pregunta, fecha_aplicable, motivo_fecha, normas_citadas, aviso_transitorio, plan_en_uso)
  values
    (v_usuario, p_pregunta, p_fecha_aplicable, p_motivo_fecha, p_normas, p_aviso_trans, v_plan)
  returning id into v_id;

  return jsonb_build_object('ok', true, 'consulta_id', v_id, 'estado', public.estado_cuenta(v_usuario));
end;
$$;

-- ---------------------------------------------------------------------
-- Alta automatica: cada usuario nuevo arranca con 24 h ilimitadas.
-- ---------------------------------------------------------------------
create or replace function public.gestionar_nuevo_usuario()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.perfiles (id, email, nombre, despacho, colegio, n_colegiado, telefono, origen)
  values (
    new.id,
    new.email,
    nullif(new.raw_user_meta_data->>'nombre',''),
    nullif(new.raw_user_meta_data->>'despacho',''),
    nullif(new.raw_user_meta_data->>'colegio',''),
    nullif(new.raw_user_meta_data->>'n_colegiado',''),
    nullif(new.raw_user_meta_data->>'telefono',''),
    nullif(new.raw_user_meta_data->>'origen','')
  )
  on conflict (id) do nothing;

  insert into public.eventos (usuario_id, tipo, metadatos)
  values (new.id, 'registro', jsonb_build_object('email', new.email));

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.gestionar_nuevo_usuario();

-- actualizado_el
create or replace function public.tocar_actualizado()
returns trigger language plpgsql as $$
begin new.actualizado_el := now(); return new; end;
$$;

create trigger perfiles_tocar
  before update on public.perfiles
  for each row execute function public.tocar_actualizado();
-- =====================================================================
-- STOA LEX · Row Level Security
-- Regla de oro: un fallo de aislamiento entre despachos es revelacion
-- de secreto profesional, no un bug de permisos. Todo cerrado por defecto.
-- =====================================================================

alter table public.perfiles         enable row level security;
alter table public.equipos          enable row level security;
alter table public.equipo_miembros  enable row level security;
alter table public.consultas        enable row level security;
alter table public.eventos          enable row level security;

-- PERFILES: cada uno el suyo. Nunca se permite cambiar plan ni Stripe desde el cliente.
create policy perfiles_select_propio on public.perfiles
  for select to authenticated using (id = (select auth.uid()));

create policy perfiles_update_propio on public.perfiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- Blindaje: solo el service_role (webhook de Stripe) toca campos de facturacion.
create or replace function public.proteger_campos_facturacion()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if current_setting('request.jwt.claims', true)::jsonb->>'role' is distinct from 'service_role' then
    new.plan                   := old.plan;
    new.trial_inicio           := old.trial_inicio;
    new.trial_fin              := old.trial_fin;
    new.stripe_customer_id     := old.stripe_customer_id;
    new.stripe_subscription_id := old.stripe_subscription_id;
    new.estado_suscripcion     := old.estado_suscripcion;
    new.periodo_actual_fin     := old.periodo_actual_fin;
    new.cancelar_al_final      := old.cancelar_al_final;
    new.contactado             := old.contactado;
    new.contactado_el          := old.contactado_el;
    new.notas_internas         := old.notas_internas;
  end if;
  return new;
end;
$$;

create trigger perfiles_proteger
  before update on public.perfiles
  for each row execute function public.proteger_campos_facturacion();

-- CONSULTAS: propias, o del equipo si eres propietario (expedientes compartidos).
create policy consultas_select_propias on public.consultas
  for select to authenticated using (usuario_id = (select auth.uid()));

-- Insercion solo via registrar_consulta() (security definer), nunca directa.
create policy consultas_no_insert_directo on public.consultas
  for insert to authenticated with check (false);

-- EQUIPOS
create policy equipos_select_miembro on public.equipos
  for select to authenticated
  using (exists (
    select 1 from public.equipo_miembros m
    where m.equipo_id = equipos.id and m.usuario_id = (select auth.uid())
  ));

create policy miembros_select_propio_equipo on public.equipo_miembros
  for select to authenticated
  using (exists (
    select 1 from public.equipo_miembros m2
    where m2.equipo_id = equipo_miembros.equipo_id and m2.usuario_id = (select auth.uid())
  ));

-- EVENTOS: el usuario ve los suyos; nadie escribe desde el cliente.
create policy eventos_select_propios on public.eventos
  for select to authenticated using (usuario_id = (select auth.uid()));

create policy eventos_no_insert_directo on public.eventos
  for insert to authenticated with check (false);

-- ---------------------------------------------------------------------
-- Vista de panel comercial (solo service_role / SQL editor).
-- Es la lista de "a quien llamamos manana".
-- ---------------------------------------------------------------------
create or replace view public.panel_comercial
with (security_invoker = true) as
select
  p.id,
  p.email,
  p.nombre,
  p.despacho,
  p.colegio,
  p.telefono,
  p.creado_el,
  p.trial_fin,
  public.plan_efectivo(p.id)                                as plan_actual,
  (p.trial_fin > now())                                     as en_prueba,
  (select count(*) from public.consultas c where c.usuario_id = p.id) as consultas_totales,
  (select max(c.creada_el) from public.consultas c where c.usuario_id = p.id) as ultima_consulta,
  p.contactado,
  p.estado_suscripcion,
  p.notas_internas
from public.perfiles p;

revoke all on public.panel_comercial from anon, authenticated;
