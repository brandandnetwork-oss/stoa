# Stoa Lex · integración

Estado a 23 de agosto de 2026. La base de datos **ya está creada y funcionando**; lo que falta es
Stripe y subir el archivo.

---

## 1. Lo que ya está hecho

**Proyecto Supabase `stoalex`** — región `eu-west-3` (París, dentro de la UE, que es lo que te
permite decirle a un abogado que sus expedientes no salen del EEE).

| Dato | Valor |
|---|---|
| URL | `https://fqsgcydvjnkfhnbrlcdt.supabase.co` |
| Clave publicable | `sb_publishable_1O3BVYvcVEvVJdDSh10z-w_cl-KswJs` |
| Panel | https://supabase.com/dashboard/project/fqsgcydvjnkfhnbrlcdt |

La clave publicable va en el HTML y **es pública por diseño**: no da acceso a nada, porque todo está
protegido por políticas de fila. La que nunca debe salir del servidor es la `service_role`, que
encontrarás en *Project Settings → API*.

### Tablas

- **`perfiles`** — un registro por usuario. Plan, ventana de prueba, identificadores de Stripe y los
  campos de seguimiento comercial (`contactado`, `contactado_el`, `notas_internas`).
- **`consultas`** — cada consulta con la fecha aplicable resuelta, el motivo por el que se eligió y
  las normas citadas. Es a la vez el contador de cuota y la trazabilidad que exige la Circular 3/2026.
- **`eventos`** — embudo: `registro`, `cuota_agotada`, y los que añadas.
- **`equipos`** y **`equipo_miembros`** — plan Despacho.

### Funciones

- **`estado_cuenta()`** — lo que pinta la interfaz: plan efectivo, horas de prueba restantes, cuota
  consumida y disponible.
- **`registrar_consulta(...)`** — comprueba la cuota y registra en la misma operación. Llámala desde
  tu backend cada vez que respondas a un usuario.
- **`plan_efectivo()`** — degrada `prueba` a `free` cuando pasan las 24 h, y degrada un plan de pago a
  `free` si la suscripción deja de estar activa. **Nunca bloquea al usuario, lo conserva.**

### Seguridad

RLS activo en las cinco tablas: cada usuario solo ve sus filas. Un disparador impide que nadie
modifique desde el cliente su propio plan, su ventana de prueba ni sus campos de Stripe — solo la
`service_role` puede tocarlos. Las funciones internas están revocadas para `anon` y `authenticated`.

> Es el punto más importante de todo esto. Una fuga entre despachos en un producto jurídico no es un
> fallo de permisos: es una revelación de secreto profesional, potencialmente entre partes contrarias
> del mismo pleito.

---

## 2. Configurar el correo (10 minutos, hazlo primero)

En *Authentication → Providers → Email*: deja **Confirm email** activado. Y en *Authentication → URL
Configuration* pon `https://stoa.consulting/stoalex` como Site URL y como Redirect URL.

Las plantillas de correo vienen en inglés. Cámbialas en *Authentication → Email Templates*:

**Confirm signup** → asunto `Tus 24 horas en Stoa Lex empiezan aquí`

```html
<h2>Confirma tu correo y empieza</h2>
<p>Pulsa el enlace y tus 24 horas de acceso ilimitado arrancan en ese momento.
   Sin tarjeta y sin compromiso.</p>
<p><a href="{{ .ConfirmationURL }}">Empezar mis 24 horas</a></p>
<p style="color:#77796C;font-size:14px">
  Al terminar no te quedas a cero: pasas al plan gratuito con 10 consultas al mes.<br>
  Stoa Consulting S.L. · Madrid
</p>
```

El SMTP por defecto de Supabase está limitado y no sirve para producción. Conecta el tuyo en
*Project Settings → Authentication → SMTP* (Resend, Postmark o Brevo — Brevo ya lo tienes conectado).

---

## 3. Stripe

### 3.1 Productos y precios

Crea un producto por plan y dos precios por producto (mensual y anual). Los importes **sin IVA**;
activa *Stripe Tax* para que aplique el 21 % español automáticamente.

| Plan | Mensual | Anual | Anual equivalente |
|---|---|---|---|
| Básico | 29 € | 278 € | 23 €/mes |
| Profesional | 69 € | 662 € | 55 €/mes |
| Despacho (2 usuarios) | 129 € | 1.238 € | 103 €/mes |
| Usuario adicional | 49 € | 470 € | 39 €/mes |

Para el usuario adicional del plan Despacho usa un precio con **cantidad variable**, así el mismo
precio sirve de 0 a 13 unidades extra.

Apunta los identificadores `price_...` de los siete precios: los necesitas en el paso siguiente.

### 3.2 Endpoint de Checkout

La página llama a `POST /api/stoalex/checkout` con `{ plan, ciclo }` y el token del usuario en la
cabecera. Ese endpoint tiene que existir en tu servidor. Si stoa.consulting está en Vercel o Netlify,
una función serverless basta:

```js
// /api/stoalex/checkout
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const admin  = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY   // NUNCA en el cliente
);

const PRECIOS = {
  basico:      { mes: "price_...", ano: "price_..." },
  profesional: { mes: "price_...", ano: "price_..." },
  despacho:    { mes: "price_...", ano: "price_..." }
};

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const token = (req.headers.authorization || "").replace("Bearer ", "");
  const { data: { user }, error } = await admin.auth.getUser(token);
  if (error || !user) return res.status(401).json({ error: "no_autenticado" });

  const { plan, ciclo } = req.body;
  const price = PRECIOS[plan]?.[ciclo];
  if (!price) return res.status(400).json({ error: "plan_invalido" });

  // Reutiliza el cliente de Stripe si ya existe
  const { data: perfil } = await admin
    .from("perfiles").select("stripe_customer_id, email, nombre")
    .eq("id", user.id).single();

  let customer = perfil?.stripe_customer_id;
  if (!customer) {
    const c = await stripe.customers.create({
      email: perfil.email,
      name:  perfil.nombre || undefined,
      metadata: { supabase_user_id: user.id }
    });
    customer = c.id;
    await admin.from("perfiles")
      .update({ stripe_customer_id: customer }).eq("id", user.id);
  }

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer,
    line_items: [{ price, quantity: 1 }],
    automatic_tax: { enabled: true },
    customer_update: { address: "auto" },
    tax_id_collection: { enabled: true },      // NIF/CIF para facturar al despacho
    locale: "es",
    allow_promotion_codes: true,
    success_url: "https://stoa.consulting/stoalex?pago=ok",
    cancel_url:  "https://stoa.consulting/stoalex?pago=cancelado",
    subscription_data: { metadata: { supabase_user_id: user.id, plan } },
    metadata: { supabase_user_id: user.id, plan }
  });

  res.json({ url: session.url });
}
```

### 3.3 Webhook — la pieza que realmente activa el plan

**El plan no se activa desde el navegador.** Si lo haces así, cualquiera puede darse Profesional
gratis desde la consola del navegador. Se activa aquí, y solo aquí:

```js
// /api/stoalex/webhook   (desactiva el body parser en este endpoint)
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const admin  = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const PLAN_POR_PRICE = {
  "price_...": "basico",
  "price_...": "profesional",
  "price_...": "despacho"
  // ... los seis
};

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  const raw = await buffer(req);
  let evt;
  try {
    evt = stripe.webhooks.constructEvent(
      raw, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (e) {
    return res.status(400).send(`Firma inválida: ${e.message}`);
  }

  const sub = evt.data.object;

  switch (evt.type) {
    case "customer.subscription.created":
    case "customer.subscription.updated": {
      const userId = sub.metadata?.supabase_user_id;
      if (!userId) break;
      const priceId = sub.items.data[0].price.id;
      const estado = {
        active:   "activa",
        trialing: "periodo_prueba",
        past_due: "impago",
        unpaid:   "impago",
        canceled: "cancelada",
        incomplete: "incompleta"
      }[sub.status] || "ninguna";

      await admin.from("perfiles").update({
        plan: PLAN_POR_PRICE[priceId] || "free",
        stripe_subscription_id: sub.id,
        estado_suscripcion: estado,
        periodo_actual_fin: new Date(sub.current_period_end * 1000).toISOString(),
        cancelar_al_final: sub.cancel_at_period_end
      }).eq("id", userId);
      break;
    }

    case "customer.subscription.deleted": {
      const userId = sub.metadata?.supabase_user_id;
      if (!userId) break;
      // No se borra nada: el usuario vuelve al plan gratuito.
      await admin.from("perfiles").update({
        plan: "free",
        estado_suscripcion: "cancelada",
        stripe_subscription_id: null
      }).eq("id", userId);
      break;
    }

    case "invoice.payment_failed": {
      // Aquí es donde avisas por correo antes de degradar.
      break;
    }
  }

  res.json({ received: true });
}
```

Registra el webhook en Stripe apuntando a `https://stoa.consulting/api/stoalex/webhook` y suscríbelo
a `customer.subscription.created`, `.updated`, `.deleted` e `invoice.payment_failed`.

### 3.4 Portal de cliente

Para que puedan cambiar de plan, actualizar la tarjeta o cancelar sin escribirte, activa el
*Customer Portal* en Stripe y crea `/api/stoalex/portal`:

```js
const session = await stripe.billingPortal.sessions.create({
  customer,
  return_url: "https://stoa.consulting/stoalex",
  locale: "es"
});
res.json({ url: session.url });
```

En el portal, **desactiva el preaviso y deja la cancelación inmediata al final del periodo**. Es lo
que prometes en la página y lo que te diferencia de quien esconde permanencia en las condiciones.

---

## 4. Variables de entorno

```
SUPABASE_URL=https://fqsgcydvjnkfhnbrlcdt.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...        # Project Settings -> API. Solo servidor.
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

---

## 5. Publicar la página

El archivo `stoalex.html` es autocontenido: sin dependencias salvo la fuente de Google y el SDK de
Supabase, ambos por CDN.

- **WordPress** → página nueva con slug `stoalex`, bloque HTML personalizado, pegar el contenido.
- **Estático / Vercel / Netlify** → `stoalex/index.html` en la raíz.

Trae un detalle útil: si el SDK de Supabase no carga, la página entra sola en **modo vista previa**,
muestra un aviso arriba y simula el alta. Así puedes enseñarla a cualquiera sin que se registre nadie
de verdad. En tu servidor el SDK carga y funciona contra la base real, sin tocar una línea.

---

## 6. El seguimiento comercial

La consulta que abres cada mañana, en el editor SQL de Supabase:

```sql
-- A quién llamar hoy: probaron ayer, usaron el producto y aún no han pagado
select email, nombre, despacho, telefono, colegio,
       creado_el, trial_fin,
       (select count(*) from consultas c where c.usuario_id = p.id) as consultas,
       (select max(creada_el) from consultas c where c.usuario_id = p.id) as ultima
from perfiles p
where trial_fin < now()
  and trial_fin > now() - interval '3 days'
  and estado_suscripcion = 'ninguna'
  and contactado = false
  and (select count(*) from consultas c where c.usuario_id = p.id) >= 3
order by consultas desc;
```

El filtro de **tres consultas o más** es deliberado: quien probó y no usó el producto no es un
cliente, es ruido. Llama a quien lo usó de verdad.

Al cerrar la llamada:

```sql
update perfiles
set contactado = true, contactado_el = now(), notas_internas = 'Llamada 24/08: pide plan despacho'
where email = 'ejemplo@despacho.es';
```

---

## 7. Antes de abrirlo al público

- [ ] SMTP propio configurado y correo de confirmación probado con una cuenta real
- [ ] Los siete precios creados en Stripe y sus identificadores en el endpoint
- [ ] Webhook registrado y probado con `stripe listen --forward-to`
- [ ] Un pago de prueba completo en modo test, y comprobar que `perfiles.plan` cambia solo
- [ ] Aviso de privacidad y condiciones publicados, con la cláusula de **sin permanencia** por escrito
- [ ] Contrato de encargo del tratamiento (art. 28 RGPD) listo para los despachos que lo pidan
- [ ] Aviso persistente de que es un sistema de IA (art. 50 del Reglamento de IA, en vigor desde el
      2 de agosto de 2026)
- [ ] Registro de trazabilidad exportable por el usuario, para que pueda aportarlo a su colegio
- [ ] Rate limiting en el endpoint de consultas, o el plan gratuito te costará dinero real
